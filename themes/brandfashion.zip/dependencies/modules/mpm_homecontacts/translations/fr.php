<?php

  global $_MODULE;
  $_MODULE = array();
  $_MODULE['<{mpm_homecontacts}prestashop>mpm_homecontacts_047909663a29669437991adf0b47ea51'] = 'Home contacts';
  $_MODULE['<{mpm_homecontacts}prestashop>mpm_homecontacts_7edb21f868cc6855551e791f3447e692'] = 'Home contacts block.';
  $_MODULE['<{mpm_homecontacts}prestashop>mpm_homecontacts_876f23178c29dc2552c0b48bf23cd9bd'] = 'Êtes-vous sûr de vouloir désinstaller ?';
  $_MODULE['<{mpm_homecontacts}prestashop>adminhomecontactscontroller_d3b206d196cd6be3a2764c1fb90b200f'] = 'Supprimer la sélection';
  $_MODULE['<{mpm_homecontacts}prestashop>adminhomecontactscontroller_e25f0ecd41211b01c83e5fec41df4fe7'] = 'Supprimer les éléments sélectionnés ?';
  $_MODULE['<{mpm_homecontacts}prestashop>adminhomecontactscontroller_b718adec73e04ce3ec720dd11a06a308'] = 'ID';
  $_MODULE['<{mpm_homecontacts}prestashop>adminhomecontactscontroller_f4f70727dc34561dfde1a3c529b6205c'] = 'Paramètres';
  $_MODULE['<{mpm_homecontacts}prestashop>adminhomecontactscontroller_b7628c9b084b7e6a543ad77801ec89a6'] = 'Bloc « téléphone »';
  $_MODULE['<{mpm_homecontacts}prestashop>adminhomecontactscontroller_bcc254b55c4a1babdf1dcb82c207506b'] = 'Téléphone';
  $_MODULE['<{mpm_homecontacts}prestashop>adminhomecontactscontroller_9b7d00f847ccfad8224b25c0f5c72332'] = 'Description';
  $_MODULE['<{mpm_homecontacts}prestashop>adminhomecontactscontroller_6252c0f2c2ed83b7b06dfca86d4650bb'] = 'Caractères interdits:';
  $_MODULE['<{mpm_homecontacts}prestashop>adminhomecontactscontroller_92b17e0cf8ec2375044ca1d0fd0781ac'] = 'Bloc « E-mail »';
  $_MODULE['<{mpm_homecontacts}prestashop>adminhomecontactscontroller_ce8ae9da5b7cd6c3df2929543a9af92d'] = 'E-mail';
  $_MODULE['<{mpm_homecontacts}prestashop>adminhomecontactscontroller_eb675b29e685137da36f8bfb7279ce4b'] = 'Description';
  $_MODULE['<{mpm_homecontacts}prestashop>adminhomecontactscontroller_4e76fa5a062dafb57870ee8293156f9d'] = 'Bloc « jours de travail »';
  $_MODULE['<{mpm_homecontacts}prestashop>adminhomecontactscontroller_0220f9387f827dab6b7b25b52e108928'] = 'Journées de travail';
  $_MODULE['<{mpm_homecontacts}prestashop>adminhomecontactscontroller_e39b170f7894bb0d5b55947926d1f941'] = 'Description';
  $_MODULE['<{mpm_homecontacts}prestashop>adminhomecontactscontroller_c9cc8cce247e49bae79f15173ce97354'] = 'Enregistrer';
  $_MODULE['<{mpm_homecontacts}prestashop>adminhomecontactscontroller_9ea67be453eaccf020697b4654fc021a'] = 'Enregistrer et rester';