<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{mpm_facebookfooter}prestashop>mpm_facebookfooter_cf670ae1261f3c1f610c54986cc8ba60'] = 'Facebook block in footer';
$_MODULE['<{mpm_facebookfooter}prestashop>mpm_facebookfooter_e2887a32ddafab9926516d8cb29aab76'] = 'Displays a block for subscribing to your Facebook Page.';
$_MODULE['<{mpm_facebookfooter}prestashop>mpm_facebookfooter_20015706a8cbd457cbb6ea3e7d5dc9b3'] = 'Konfiguracja zaktualizowana';
$_MODULE['<{mpm_facebookfooter}prestashop>mpm_facebookfooter_f4f70727dc34561dfde1a3c529b6205c'] = 'Ustawienia';
$_MODULE['<{mpm_facebookfooter}prestashop>mpm_facebookfooter_c98cf18081245e342d7929c117066f0b'] = 'Link do Facebook\'a (podaj pełny URL)';
$_MODULE['<{mpm_facebookfooter}prestashop>mpm_facebookfooter_c9cc8cce247e49bae79f15173ce97354'] = 'Zapisz';
$_MODULE['<{mpm_facebookfooter}prestashop>blockfacebookfooter_374fe11018588d3d27e630b2dffb7909'] = 'Śledź nas na Facebooku';
