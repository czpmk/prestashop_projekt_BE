<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{mpm_homeblocks}prestashop>mpm_homeblocks_9bf32a5f226323faea682d3a6b91123a'] = 'Home page custom blocks';
$_MODULE['<{mpm_homeblocks}prestashop>adminblockshomecontroller_d3b206d196cd6be3a2764c1fb90b200f'] = 'Auswahl löschen';
$_MODULE['<{mpm_homeblocks}prestashop>adminblockshomecontroller_e25f0ecd41211b01c83e5fec41df4fe7'] = 'Ausgewählte Elemente löschen?';
$_MODULE['<{mpm_homeblocks}prestashop>adminblockshomecontroller_b718adec73e04ce3ec720dd11a06a308'] = 'ID';
$_MODULE['<{mpm_homeblocks}prestashop>adminblockshomecontroller_86754577897acfb25deb69039d49d9a7'] = 'Anzeigen';
$_MODULE['<{mpm_homeblocks}prestashop>adminblockshomecontroller_52f5e0bc3859bc5f5e25130b6c7e8881'] = 'Position';
$_MODULE['<{mpm_homeblocks}prestashop>adminblockshomecontroller_7b6e7f81d1c260b7068ca82b91eb90a7'] = 'Datum hinzufügen';
$_MODULE['<{mpm_homeblocks}prestashop>adminblockshomecontroller_f4f70727dc34561dfde1a3c529b6205c'] = 'Einstellungen';
$_MODULE['<{mpm_homeblocks}prestashop>adminblockshomecontroller_4d3d769b812b6faa6b76e1a8abaece2d'] = 'Aktiv';
$_MODULE['<{mpm_homeblocks}prestashop>adminblockshomecontroller_93cba07454f06a4a960172bbd6e2a435'] = 'Ja';
$_MODULE['<{mpm_homeblocks}prestashop>adminblockshomecontroller_bafd7322c6e97d25b6299b5d6fe8920b'] = 'Nein';
$_MODULE['<{mpm_homeblocks}prestashop>adminblockshomecontroller_32954654ac8fe66a1d09be19001de2d4'] = 'Breite';
$_MODULE['<{mpm_homeblocks}prestashop>adminblockshomecontroller_cb5298bdde6546e4aa6bcd4a0ba04214'] = 'Block-Breite in \\"%\\".';
$_MODULE['<{mpm_homeblocks}prestashop>adminblockshomecontroller_c1cb156fb1f0d17288a0ab6d3971bb5a'] = 'Mindesthöhe';
$_MODULE['<{mpm_homeblocks}prestashop>adminblockshomecontroller_d6d636f547f6c65853b2b1010f43fdd0'] = 'Mindesthöhe in \\"px\\".';
$_MODULE['<{mpm_homeblocks}prestashop>adminblockshomecontroller_a9ded1e5ce5d75814730bb4caaf49419'] = 'Hintergrund';
$_MODULE['<{mpm_homeblocks}prestashop>adminblockshomecontroller_368d9ac76af05f714092bc808a426bfc'] = 'Hintergrundfarbe';
$_MODULE['<{mpm_homeblocks}prestashop>adminblockshomecontroller_22cbf85c41427960736dc10cfec5faf4'] = 'Farbe aus Farbpalette auswählen oder eine HTML-Farbe eingeben (z.B. \\"hellblau\\", \\"#CC6600\\").';
$_MODULE['<{mpm_homeblocks}prestashop>adminblockshomecontroller_6f7d1ec7ec17033b4973444ccfe99b9f'] = 'Beschreibung zum linken Block';
$_MODULE['<{mpm_homeblocks}prestashop>adminblockshomecontroller_6252c0f2c2ed83b7b06dfca86d4650bb'] = 'Ungültige Zeichen:';
$_MODULE['<{mpm_homeblocks}prestashop>adminblockshomecontroller_c9cc8cce247e49bae79f15173ce97354'] = 'Speichern';
$_MODULE['<{mpm_homeblocks}prestashop>adminblockshomecontroller_9ea67be453eaccf020697b4654fc021a'] = 'Speichern und auf der Seite bleiben';
