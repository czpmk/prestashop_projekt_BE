<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{mpm_subcategories}prestashop>mpm_subcategories_e2fd1ecac64d5757d70058687d9c7727'] = 'Subcategories block';
$_MODULE['<{mpm_subcategories}prestashop>mpm_subcategories_6a6bc4eaa7e36a9f203ca4a4bb5b9ec9'] = 'Displays subcategories block on category page.';
$_MODULE['<{mpm_subcategories}prestashop>mpm_subcategories_f38f5974cdc23279ffe6d203641a8bdf'] = 'Ustawienia zaktualizowane.';
$_MODULE['<{mpm_subcategories}prestashop>mpm_subcategories_f4f70727dc34561dfde1a3c529b6205c'] = 'Ustawienia';
$_MODULE['<{mpm_subcategories}prestashop>mpm_subcategories_7181f71d1f7b5f3e51e247f40b901bae'] = 'Wyświetlaj suwak podkategorii';
$_MODULE['<{mpm_subcategories}prestashop>mpm_subcategories_00d23a76e43b46dae9ec7aa9dcbebb32'] = 'Włączony';
$_MODULE['<{mpm_subcategories}prestashop>mpm_subcategories_b9f5c797ebbf55adccdd8539a65a0241'] = 'Wyłączony';
$_MODULE['<{mpm_subcategories}prestashop>mpm_subcategories_b605530eb3bf38451e49daa30e1d2e68'] = 'Wyświetlaj obraz kategorii';
$_MODULE['<{mpm_subcategories}prestashop>mpm_subcategories_29c93e5b541f931139905702e890494a'] = 'Wyświetlaj opis kategorii';
$_MODULE['<{mpm_subcategories}prestashop>mpm_subcategories_c9cc8cce247e49bae79f15173ce97354'] = 'Zapisz';
$_MODULE['<{mpm_subcategories}prestashop>subcategories_f73cc399b5ce12735a57f03414f09ef9'] = 'Podkategorie';
