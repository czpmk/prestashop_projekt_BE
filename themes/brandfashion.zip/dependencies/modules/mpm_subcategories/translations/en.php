<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{mpm_subcategories}prestashop>mpm_subcategories_e2fd1ecac64d5757d70058687d9c7727'] = 'Subcategories block';
$_MODULE['<{mpm_subcategories}prestashop>mpm_subcategories_6a6bc4eaa7e36a9f203ca4a4bb5b9ec9'] = 'Displays subcategories block on category page.';
$_MODULE['<{mpm_subcategories}prestashop>mpm_subcategories_f38f5974cdc23279ffe6d203641a8bdf'] = 'Settings updated.';
$_MODULE['<{mpm_subcategories}prestashop>mpm_subcategories_f4f70727dc34561dfde1a3c529b6205c'] = 'Settings';
$_MODULE['<{mpm_subcategories}prestashop>mpm_subcategories_7181f71d1f7b5f3e51e247f40b901bae'] = 'Display subcategories slider';
$_MODULE['<{mpm_subcategories}prestashop>mpm_subcategories_00d23a76e43b46dae9ec7aa9dcbebb32'] = 'Enabled';
$_MODULE['<{mpm_subcategories}prestashop>mpm_subcategories_b9f5c797ebbf55adccdd8539a65a0241'] = 'Disabled';
$_MODULE['<{mpm_subcategories}prestashop>mpm_subcategories_b605530eb3bf38451e49daa30e1d2e68'] = 'Display category image';
$_MODULE['<{mpm_subcategories}prestashop>mpm_subcategories_29c93e5b541f931139905702e890494a'] = 'Display category description';
$_MODULE['<{mpm_subcategories}prestashop>mpm_subcategories_c9cc8cce247e49bae79f15173ce97354'] = 'Save';
$_MODULE['<{mpm_subcategories}prestashop>subcategories_af1b98adf7f686b84cd0b443e022b7a0'] = 'Categories';