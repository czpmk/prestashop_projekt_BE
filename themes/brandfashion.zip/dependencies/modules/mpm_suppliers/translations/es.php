<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{mpm_suppliers}prestashop>mpm_suppliers_1814d65a76028fdfbadab64a5a8076df'] = 'Bloque proveedor';
$_MODULE['<{mpm_suppliers}prestashop>mpm_suppliers_2ea9d480cd8e6dd9dabde883c6da32de'] = 'Bloque proveedor.';
$_MODULE['<{mpm_suppliers}prestashop>mpm_suppliers_876f23178c29dc2552c0b48bf23cd9bd'] = '¿Seguro que quieres desinstalar?';
$_MODULE['<{mpm_suppliers}prestashop>mpm_suppliers_85ab0c0d250e58397e95c96277a3f8e3'] = 'Número de elementos incorrecto.';
$_MODULE['<{mpm_suppliers}prestashop>mpm_suppliers_f38f5974cdc23279ffe6d203641a8bdf'] = 'Configuración actualizada.';
$_MODULE['<{mpm_suppliers}prestashop>mpm_suppliers_19fb21d55a90e1c8d1d88cdcc8becbda'] = 'displayHomeContent1';
$_MODULE['<{mpm_suppliers}prestashop>mpm_suppliers_940598f5e00b8924dae0d72aa03542bb'] = 'displayHomeContent2';
$_MODULE['<{mpm_suppliers}prestashop>mpm_suppliers_d0c6b51eb278a01ec6df0dfb6a5b6320'] = 'displayHomeContent3';
$_MODULE['<{mpm_suppliers}prestashop>mpm_suppliers_5ed5cbf5b35713c3951dfc84c09be952'] = 'displayHomeContent4';
$_MODULE['<{mpm_suppliers}prestashop>mpm_suppliers_cecece906a89a2ea0af8ef6de320aa2b'] = 'displayHomeContent5';
$_MODULE['<{mpm_suppliers}prestashop>mpm_suppliers_f4f70727dc34561dfde1a3c529b6205c'] = 'Ajustes';
$_MODULE['<{mpm_suppliers}prestashop>mpm_suppliers_e5b64a50c0e0da0bb75295fad5f9f8d5'] = 'Ajustes de la columna central';
$_MODULE['<{mpm_suppliers}prestashop>mpm_suppliers_79b362cbcdfe4efb9a56930826bc175f'] = 'Mostrar el bloque de proveedores en la página de inicio';
$_MODULE['<{mpm_suppliers}prestashop>mpm_suppliers_00d23a76e43b46dae9ec7aa9dcbebb32'] = 'Activado';
$_MODULE['<{mpm_suppliers}prestashop>mpm_suppliers_b9f5c797ebbf55adccdd8539a65a0241'] = 'Desactivado';
$_MODULE['<{mpm_suppliers}prestashop>mpm_suppliers_b9b371458ab7c314f88b81c553f6ce51'] = 'Hook';
$_MODULE['<{mpm_suppliers}prestashop>mpm_suppliers_d6471192b75faa517bd906dd9082bd55'] = 'Mostrar el nombre del proveedor';
$_MODULE['<{mpm_suppliers}prestashop>mpm_suppliers_474ba124e261da94f99b49c467e44d59'] = 'Mostrar el nombre del proveedor bajo el logotipo.';
$_MODULE['<{mpm_suppliers}prestashop>mpm_suppliers_1596466e53b9be856f2fa94c7d89ec33'] = 'Ajustes de la columna de la izquierda';
$_MODULE['<{mpm_suppliers}prestashop>mpm_suppliers_bd95565cc6d7a76112705714148cb3a3'] = 'Mostrar el bloque de proveedores en la columna izquierda';
$_MODULE['<{mpm_suppliers}prestashop>mpm_suppliers_2cb17a40a6c82f31ec65fd0598d5f9cf'] = 'Número de proveedores a mostrar';
$_MODULE['<{mpm_suppliers}prestashop>mpm_suppliers_c9cc8cce247e49bae79f15173ce97354'] = 'Guardar';
$_MODULE['<{mpm_suppliers}prestashop>blocksupplier_1814d65a76028fdfbadab64a5a8076df'] = 'Proveedores';
$_MODULE['<{mpm_suppliers}prestashop>blocksupplier_49fa2426b7903b3d4c89e2c1874d9346'] = 'Más sobre';
$_MODULE['<{mpm_suppliers}prestashop>suppliers_1814d65a76028fdfbadab64a5a8076df'] = 'Proveedores';
