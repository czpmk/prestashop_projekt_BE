<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{mpm_suppliers}prestashop>mpm_suppliers_1814d65a76028fdfbadab64a5a8076df'] = 'Block Lieferanten';
$_MODULE['<{mpm_suppliers}prestashop>mpm_suppliers_2ea9d480cd8e6dd9dabde883c6da32de'] = 'Block Lieferanten.';
$_MODULE['<{mpm_suppliers}prestashop>mpm_suppliers_876f23178c29dc2552c0b48bf23cd9bd'] = 'Are you sure you want to uninstall?';
$_MODULE['<{mpm_suppliers}prestashop>mpm_suppliers_85ab0c0d250e58397e95c96277a3f8e3'] = 'Ungültige Anzahl von Elementen.';
$_MODULE['<{mpm_suppliers}prestashop>mpm_suppliers_f38f5974cdc23279ffe6d203641a8bdf'] = 'Einstellungen wurden aktualisiert.';
$_MODULE['<{mpm_suppliers}prestashop>mpm_suppliers_19fb21d55a90e1c8d1d88cdcc8becbda'] = 'displayHomeContent1';
$_MODULE['<{mpm_suppliers}prestashop>mpm_suppliers_940598f5e00b8924dae0d72aa03542bb'] = 'displayHomeContent2';
$_MODULE['<{mpm_suppliers}prestashop>mpm_suppliers_d0c6b51eb278a01ec6df0dfb6a5b6320'] = 'displayHomeContent3';
$_MODULE['<{mpm_suppliers}prestashop>mpm_suppliers_5ed5cbf5b35713c3951dfc84c09be952'] = 'displayHomeContent4';
$_MODULE['<{mpm_suppliers}prestashop>mpm_suppliers_cecece906a89a2ea0af8ef6de320aa2b'] = 'displayHomeContent5';
$_MODULE['<{mpm_suppliers}prestashop>mpm_suppliers_f4f70727dc34561dfde1a3c529b6205c'] = 'Einstellungen';
$_MODULE['<{mpm_suppliers}prestashop>mpm_suppliers_e5b64a50c0e0da0bb75295fad5f9f8d5'] = 'Einstellungen zur zentrierten Spalte';
$_MODULE['<{mpm_suppliers}prestashop>mpm_suppliers_79b362cbcdfe4efb9a56930826bc175f'] = 'Lieferantenblock auf Homepage anzeigen';
$_MODULE['<{mpm_suppliers}prestashop>mpm_suppliers_00d23a76e43b46dae9ec7aa9dcbebb32'] = 'Aktiviert';
$_MODULE['<{mpm_suppliers}prestashop>mpm_suppliers_b9f5c797ebbf55adccdd8539a65a0241'] = 'Deaktiviert';
$_MODULE['<{mpm_suppliers}prestashop>mpm_suppliers_b9b371458ab7c314f88b81c553f6ce51'] = 'Hook';
$_MODULE['<{mpm_suppliers}prestashop>mpm_suppliers_d6471192b75faa517bd906dd9082bd55'] = 'Lieferantentitel anzeigen';
$_MODULE['<{mpm_suppliers}prestashop>mpm_suppliers_474ba124e261da94f99b49c467e44d59'] = 'Lieferantentitel unter dem Logo anzeigen.';
$_MODULE['<{mpm_suppliers}prestashop>mpm_suppliers_1596466e53b9be856f2fa94c7d89ec33'] = 'Einstellungen zur linken Spalte';
$_MODULE['<{mpm_suppliers}prestashop>mpm_suppliers_bd95565cc6d7a76112705714148cb3a3'] = 'Lieferantenblock in der linken Spalte anzeigen';
$_MODULE['<{mpm_suppliers}prestashop>mpm_suppliers_2cb17a40a6c82f31ec65fd0598d5f9cf'] = 'Anzahl der anzuzeigenden Lieferanten';
$_MODULE['<{mpm_suppliers}prestashop>mpm_suppliers_c9cc8cce247e49bae79f15173ce97354'] = 'Speichern';
$_MODULE['<{mpm_suppliers}prestashop>blocksupplier_1814d65a76028fdfbadab64a5a8076df'] = 'Lieferanten';
$_MODULE['<{mpm_suppliers}prestashop>blocksupplier_49fa2426b7903b3d4c89e2c1874d9346'] = 'Mehr darüber';
$_MODULE['<{mpm_suppliers}prestashop>suppliers_1814d65a76028fdfbadab64a5a8076df'] = 'Lieferanten';
