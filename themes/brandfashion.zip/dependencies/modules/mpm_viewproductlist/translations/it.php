<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{mpm_viewproductlist}prestashop>mpm_viewproductlist_2ebd2f437e74b649679883c569299d29'] = 'Product list view';
$_MODULE['<{mpm_viewproductlist}prestashop>mpm_viewproductlist_ed8c222ff4a2dc241b6a370dda03e019'] = 'Product list view.';
