<?php

  global $_MODULE;
  $_MODULE = array();
  $_MODULE['<{mpm_themeconfigurator}prestashop>mpm_themeconfigurator_e92dabb4907f1957cabc469cca4deefc'] = 'Configurateur de thème';
  $_MODULE['<{mpm_themeconfigurator}prestashop>mpm_themeconfigurator_f5a35b8e88be7f51ad3a3714a83df3a1'] = 'L\'outil de personnalisation vous permet de changer les couleurs et la police de votre thème.';
  $_MODULE['<{mpm_themeconfigurator}prestashop>mpm_themeconfigurator_f4f70727dc34561dfde1a3c529b6205c'] = 'Paramètres';
  $_MODULE['<{mpm_themeconfigurator}prestashop>mpm_themeconfigurator_75ed15adfe00306633c8712fe8e32dd2'] = 'Couleur principale de l\'arrière-plan';
  $_MODULE['<{mpm_themeconfigurator}prestashop>mpm_themeconfigurator_9d5239857e6401bcb12a87a1691db03a'] = 'Par défaut : #d19e65';
  $_MODULE['<{mpm_themeconfigurator}prestashop>mpm_themeconfigurator_b79b039c903b748e2577fb083b634c17'] = 'Couleur principale de l\'arrière-plan sur pointage';
  $_MODULE['<{mpm_themeconfigurator}prestashop>mpm_themeconfigurator_b39a0e730fd73d76514ad4652913730b'] = 'Par défaut : #ffffff';
  $_MODULE['<{mpm_themeconfigurator}prestashop>mpm_themeconfigurator_eddd2252e163c7ca51d0b068b6169c71'] = 'Arrière-plan de la page';
  $_MODULE['<{mpm_themeconfigurator}prestashop>mpm_themeconfigurator_bf79dd86ea56f36a705423139df6a4da'] = 'Couleur de l\'arrière-plan en bas de page';
  $_MODULE['<{mpm_themeconfigurator}prestashop>mpm_themeconfigurator_8c1ab413e6f9e57abfe35239d6a687df'] = 'Par défaut : #000000';
  $_MODULE['<{mpm_themeconfigurator}prestashop>mpm_themeconfigurator_c0ef1447efeab0af1d75099e77168e0d'] = 'Image de l\'arrière-plan en bas de page';
  $_MODULE['<{mpm_themeconfigurator}prestashop>mpm_themeconfigurator_010307371be5de844d863f3ebef685c3'] = 'Couleur du texte en bas de page';
  $_MODULE['<{mpm_themeconfigurator}prestashop>mpm_themeconfigurator_5dbd95201bae1e3ee5a1889b8fb2010d'] = 'Couleur du texte sur pointage en bas de page';
  $_MODULE['<{mpm_themeconfigurator}prestashop>mpm_themeconfigurator_d96cdf8c6719bb08722cdb17b27cc57f'] = 'Police du modèle';
  $_MODULE['<{mpm_themeconfigurator}prestashop>mpm_themeconfigurator_194f5394ae2e9c74dc3c441b92862d1d'] = 'Police';
  $_MODULE['<{mpm_themeconfigurator}prestashop>mpm_themeconfigurator_eef726af49326ebfdf6816089c4229dc'] = 'Par défaut : Lato';
  $_MODULE['<{mpm_themeconfigurator}prestashop>mpm_themeconfigurator_9daf6056aa0d34486551a12e1d6b9163'] = 'Paramètres de catégorie';
  $_MODULE['<{mpm_themeconfigurator}prestashop>mpm_themeconfigurator_b605530eb3bf38451e49daa30e1d2e68'] = 'Afficher la catégorie de l\'image';
  $_MODULE['<{mpm_themeconfigurator}prestashop>mpm_themeconfigurator_00d23a76e43b46dae9ec7aa9dcbebb32'] = 'Activé';
  $_MODULE['<{mpm_themeconfigurator}prestashop>mpm_themeconfigurator_b9f5c797ebbf55adccdd8539a65a0241'] = 'Désactivé';
  $_MODULE['<{mpm_themeconfigurator}prestashop>mpm_themeconfigurator_29c93e5b541f931139905702e890494a'] = 'Afficher la description de l\'image';
  $_MODULE['<{mpm_themeconfigurator}prestashop>mpm_themeconfigurator_4d4d488d19596e4c9bf2f889ee5020b3'] = 'Afficher la série des sous-catégories sur la page de catégorie';
  $_MODULE['<{mpm_themeconfigurator}prestashop>mpm_themeconfigurator_e404bb156af00aa8398efd98c6994f53'] = 'Activer le zoom sur pointage pour les images de produit ';
  $_MODULE['<{mpm_themeconfigurator}prestashop>mpm_themeconfigurator_c9cc8cce247e49bae79f15173ce97354'] = 'Enregistrer';
  $_MODULE['<{mpm_themeconfigurator}prestashop>mpm_themeconfigurator_efc226b17e0532afff43be870bff0de7'] = 'Paramètres mis à jour.';
