<?php

  global $_MODULE;
  $_MODULE = array();
  $_MODULE['<{mpm_themeconfigurator}prestashop>mpm_themeconfigurator_e92dabb4907f1957cabc469cca4deefc'] = 'Konfigurator motywu';
  $_MODULE['<{mpm_themeconfigurator}prestashop>mpm_themeconfigurator_f5a35b8e88be7f51ad3a3714a83df3a1'] = 'Narzędzie pozwala na dostosowanie kolorów i czcionek w twoim szablonie.';
  $_MODULE['<{mpm_themeconfigurator}prestashop>mpm_themeconfigurator_f4f70727dc34561dfde1a3c529b6205c'] = 'Ustawienia';
  $_MODULE['<{mpm_themeconfigurator}prestashop>mpm_themeconfigurator_75ed15adfe00306633c8712fe8e32dd2'] = 'Kolor głównego tła';
  $_MODULE['<{mpm_themeconfigurator}prestashop>mpm_themeconfigurator_9d5239857e6401bcb12a87a1691db03a'] = 'Domyślna: #d19e65';
  $_MODULE['<{mpm_themeconfigurator}prestashop>mpm_themeconfigurator_b79b039c903b748e2577fb083b634c17'] = 'Kolor głównego tła po najechaniu na niego myszką';
  $_MODULE['<{mpm_themeconfigurator}prestashop>mpm_themeconfigurator_b39a0e730fd73d76514ad4652913730b'] = 'Domyślne: #ffffff';
  $_MODULE['<{mpm_themeconfigurator}prestashop>mpm_themeconfigurator_eddd2252e163c7ca51d0b068b6169c71'] = 'Tło strony';
  $_MODULE['<{mpm_themeconfigurator}prestashop>mpm_themeconfigurator_bf79dd86ea56f36a705423139df6a4da'] = 'Kolor tła w stopce';
  $_MODULE['<{mpm_themeconfigurator}prestashop>mpm_themeconfigurator_8c1ab413e6f9e57abfe35239d6a687df'] = 'Wartość domyślna: #000000';
  $_MODULE['<{mpm_themeconfigurator}prestashop>mpm_themeconfigurator_c0ef1447efeab0af1d75099e77168e0d'] = 'Obraz tła stopki';
  $_MODULE['<{mpm_themeconfigurator}prestashop>mpm_themeconfigurator_010307371be5de844d863f3ebef685c3'] = 'Kolor tekstu w stopce';
  $_MODULE['<{mpm_themeconfigurator}prestashop>mpm_themeconfigurator_5dbd95201bae1e3ee5a1889b8fb2010d'] = 'Kolor tekstu w stopce po najechaniu na niego myszką';
  $_MODULE['<{mpm_themeconfigurator}prestashop>mpm_themeconfigurator_d96cdf8c6719bb08722cdb17b27cc57f'] = 'Czcionka szablonu';
  $_MODULE['<{mpm_themeconfigurator}prestashop>mpm_themeconfigurator_194f5394ae2e9c74dc3c441b92862d1d'] = 'Czcionka';
  $_MODULE['<{mpm_themeconfigurator}prestashop>mpm_themeconfigurator_eef726af49326ebfdf6816089c4229dc'] = 'Domyślne: Lato';
  $_MODULE['<{mpm_themeconfigurator}prestashop>mpm_themeconfigurator_9daf6056aa0d34486551a12e1d6b9163'] = 'Category Settings';
  $_MODULE['<{mpm_themeconfigurator}prestashop>mpm_themeconfigurator_b605530eb3bf38451e49daa30e1d2e68'] = 'Wyświetlaj obraz kategorii';
  $_MODULE['<{mpm_themeconfigurator}prestashop>mpm_themeconfigurator_00d23a76e43b46dae9ec7aa9dcbebb32'] = 'Włączony';
  $_MODULE['<{mpm_themeconfigurator}prestashop>mpm_themeconfigurator_b9f5c797ebbf55adccdd8539a65a0241'] = 'Wyłączony';
  $_MODULE['<{mpm_themeconfigurator}prestashop>mpm_themeconfigurator_29c93e5b541f931139905702e890494a'] = 'Wyświetlaj opis kategorii';
  $_MODULE['<{mpm_themeconfigurator}prestashop>mpm_themeconfigurator_4d4d488d19596e4c9bf2f889ee5020b3'] = 'Display subcategories block on category page';
  $_MODULE['<{mpm_themeconfigurator}prestashop>mpm_themeconfigurator_e404bb156af00aa8398efd98c6994f53'] = 'Aktywuj powiększenie zdjęcia produktu po najechaniu na niego myszką';
  $_MODULE['<{mpm_themeconfigurator}prestashop>mpm_themeconfigurator_c9cc8cce247e49bae79f15173ce97354'] = 'Zapisz';
  $_MODULE['<{mpm_themeconfigurator}prestashop>mpm_themeconfigurator_efc226b17e0532afff43be870bff0de7'] = 'Ustawienia są zaktualizowane.';
