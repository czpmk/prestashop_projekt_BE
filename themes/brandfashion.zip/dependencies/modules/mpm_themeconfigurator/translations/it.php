<?php

  global $_MODULE;
  $_MODULE = array();
  $_MODULE['<{mpm_themeconfigurator}prestashop>mpm_themeconfigurator_e92dabb4907f1957cabc469cca4deefc'] = 'Configuratore del tema';
  $_MODULE['<{mpm_themeconfigurator}prestashop>mpm_themeconfigurator_f5a35b8e88be7f51ad3a3714a83df3a1'] = 'L\'utility di personalizzazione ti permette di modificare colori e font del tuo tema.';
  $_MODULE['<{mpm_themeconfigurator}prestashop>mpm_themeconfigurator_f4f70727dc34561dfde1a3c529b6205c'] = 'Impostazioni';
  $_MODULE['<{mpm_themeconfigurator}prestashop>mpm_themeconfigurator_75ed15adfe00306633c8712fe8e32dd2'] = 'Colore principale dello sfondo';
  $_MODULE['<{mpm_themeconfigurator}prestashop>mpm_themeconfigurator_9d5239857e6401bcb12a87a1691db03a'] = 'Predefinito: #d19e65';
  $_MODULE['<{mpm_themeconfigurator}prestashop>mpm_themeconfigurator_b79b039c903b748e2577fb083b634c17'] = 'Colore principale dello sfondo al passaggio';
  $_MODULE['<{mpm_themeconfigurator}prestashop>mpm_themeconfigurator_b39a0e730fd73d76514ad4652913730b'] = 'Predefinito: #ffffff';
  $_MODULE['<{mpm_themeconfigurator}prestashop>mpm_themeconfigurator_eddd2252e163c7ca51d0b068b6169c71'] = 'Sfondo della Pagina';
  $_MODULE['<{mpm_themeconfigurator}prestashop>mpm_themeconfigurator_bf79dd86ea56f36a705423139df6a4da'] = 'Colore dello sfondo a piè di pagina';
  $_MODULE['<{mpm_themeconfigurator}prestashop>mpm_themeconfigurator_8c1ab413e6f9e57abfe35239d6a687df'] = 'Predefinito: #000000';
  $_MODULE['<{mpm_themeconfigurator}prestashop>mpm_themeconfigurator_c0ef1447efeab0af1d75099e77168e0d'] = 'Immagine dello sfondo a piè di pagina';
  $_MODULE['<{mpm_themeconfigurator}prestashop>mpm_themeconfigurator_010307371be5de844d863f3ebef685c3'] = 'Colore del testo a piè di pagina';
  $_MODULE['<{mpm_themeconfigurator}prestashop>mpm_themeconfigurator_5dbd95201bae1e3ee5a1889b8fb2010d'] = 'Colore del testo a piè di pagina al passaggio';
  $_MODULE['<{mpm_themeconfigurator}prestashop>mpm_themeconfigurator_d96cdf8c6719bb08722cdb17b27cc57f'] = 'Font del modello';
  $_MODULE['<{mpm_themeconfigurator}prestashop>mpm_themeconfigurator_194f5394ae2e9c74dc3c441b92862d1d'] = 'Tipo di carattere';
  $_MODULE['<{mpm_themeconfigurator}prestashop>mpm_themeconfigurator_eef726af49326ebfdf6816089c4229dc'] = 'Predefinito: Lato';
  $_MODULE['<{mpm_themeconfigurator}prestashop>mpm_themeconfigurator_9daf6056aa0d34486551a12e1d6b9163'] = 'Impostazioni categoria';
  $_MODULE['<{mpm_themeconfigurator}prestashop>mpm_themeconfigurator_b605530eb3bf38451e49daa30e1d2e68'] = 'Mostra immagine di categoria';
  $_MODULE['<{mpm_themeconfigurator}prestashop>mpm_themeconfigurator_00d23a76e43b46dae9ec7aa9dcbebb32'] = 'Attivato';
  $_MODULE['<{mpm_themeconfigurator}prestashop>mpm_themeconfigurator_b9f5c797ebbf55adccdd8539a65a0241'] = 'Disattivato';
  $_MODULE['<{mpm_themeconfigurator}prestashop>mpm_themeconfigurator_29c93e5b541f931139905702e890494a'] = 'Mostra descrizione di categoria';
  $_MODULE['<{mpm_themeconfigurator}prestashop>mpm_themeconfigurator_4d4d488d19596e4c9bf2f889ee5020b3'] = 'Mostra blocco delle sottocategorie sulla pagina delle categorie';
  $_MODULE['<{mpm_themeconfigurator}prestashop>mpm_themeconfigurator_e404bb156af00aa8398efd98c6994f53'] = 'Attiva lo zoom al passaggio per le immagini del prodotto';
  $_MODULE['<{mpm_themeconfigurator}prestashop>mpm_themeconfigurator_c9cc8cce247e49bae79f15173ce97354'] = 'Salva';
  $_MODULE['<{mpm_themeconfigurator}prestashop>mpm_themeconfigurator_efc226b17e0532afff43be870bff0de7'] = 'Le impostazioni sono state aggiornate.';
